<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{cronjobs}prestashop>cronjobsforms_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_d4169d52732e9ae8df56d2cbcad81a94'] = 'Descripción de la tarea';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_70d4968bea9a6e76c0333904b9d385e4'] = 'Actualizar mis monedas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_0eff773cf33456a033e913f6ed18045c'] = 'Objetivo del enlace';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_07045abc579615634804f42bc0b2b4bb'] = 'Escriba una descripción para esta tarea.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_43773e69610c99be6c15daa4a2036443'] = 'Establece el enlace a su tarea programada.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_3a21e2309e8e6aa3759e466154508f2c'] = '¡No olvide usar una URL absoluta para que sea válido! El enlace también debe de estar en el mismo dominio que la tienda.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_be938fb8c5582085599dfa95368fb489'] = 'Frecuencia de la tarea';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b3364fad867d47ca61265fd315e4071e'] = '¿A qué hora debe ejecutarse esta tarea?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_6c5d30049c4d8d644bd35650be4ac13a'] = '¿Qué día del mes debe ejecutarse esta tarea?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_a1457ee25ec20fa032d37509b5a90a4e'] = '¿Qué mes debe ejecutarse esta tarea?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_65f768d204a3118f426c756056bef1e1'] = '¿Qué día de la semana debe ejecutarse esta tarea?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b3419e63398ccc41c062f36631bebd9a'] = 'Modo Cron';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_972e73b7a882d0802a4e3a16946a2f94'] = 'Básico';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_eaf1dc6d93a18adb2619233d8e99c197'] = 'Usa el servicio web de tareas Cron de PrestaShop para ejecutar sus tareas.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_9b6545e4cea9b4ad4979d41bb9170e2b'] = 'Avanzado';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b6610b26530c9ee3d7bc4a478cf35299'] = 'Sólo para usuarios avanzados: use su propio gestor de crontab en vez del servicio de las tareas cron de PrestaShop.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_2257d36bcb68362b24cf74f626bac599'] = 'El modo avanzado permite que usted utilice su propio gestor de tareas cron en lugar del servicio web de tareas cron de  PrestaShop.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_94ad8b9f9d516489693dd835cf22bd3b'] = 'Antes que nada, asegúrese de que la librería "curl" está instalada en su servidor.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_18028ef85b7ce8fbde749a2c49c6d18a'] = 'Para ejecutar sus tareas cron, por favor, inserte la siguiente línea en su gestor de tareas cron:';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b55e509c697e4cca0e1d160a7806698f'] = 'Hora';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_03727ac48595a24daed975559c944a44'] = 'Día';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_7cbb885aa1164b390a0bc050a64e1812'] = 'Mes';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_e59278675b8f1e052b22b7e5e7d65da7'] = 'Día de la semana';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_8cebfac3b4821cbc83041f5df54d7730'] = 'Última ejecución';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_1e3208e0b0d5de9281f88c34169cda6b'] = 'Una ronda';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activar';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_bdb6ae0d03e6793183349e00f67657f6'] = 'Módulo - Hook';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_02fd27d2951d00b83f111f63611ea863'] = 'Cada hora';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_48bf14c419a1d441412510faf39c326d'] = 'Cada día';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_8ed91b71d01993965915f3b296c20336'] = 'Cada mes';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_50875e72e1477618055d1508112199b4'] = 'Todos los días de la semana';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_6e7b34fa59e1bd229b207892956dc41c'] = 'Nunca';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_16ed0a7b977ec3bbd23badfb5580d56f'] = 'Todos los días del mes';
$_MODULE['<{cronjobs}prestashop>cronjobs_682ee2e41e510efdbced967430173c66'] = 'Gestor de tareas cron';
$_MODULE['<{cronjobs}prestashop>cronjobs_c75e110ddb05aea61563c50d7baf0ae0'] = 'Gestione todas sus tareas automatizadas desde una única interfaz.';
$_MODULE['<{cronjobs}prestashop>cronjobs_4093808c9781fb6ca2ed5ade71deff4d'] = 'Para poder utilizar este módulo, por favor, active cURL (una extensión de PHP).';
$_MODULE['<{cronjobs}prestashop>cronjobs_035d5cdab2c65ad42b303f8125025160'] = 'Tareas cron';
$_MODULE['<{cronjobs}prestashop>cronjobs_6588952424b58b4c9fc9df026b668991'] = 'Añadir nueva tarea';
$_MODULE['<{cronjobs}prestashop>form_ef7bd68a02b6b5656554f7a27d1c7bdf'] = '¡Error!';
$_MODULE['<{cronjobs}prestashop>form_dc3fd488f03d423a04da27ce66274c1b'] = '¡Atención!';
$_MODULE['<{cronjobs}prestashop>form_402e7a087747cb56c718bde84651f96a'] = '¡Éxito!';
$_MODULE['<{cronjobs}prestashop>configure_27c1f598c2b2b0a8e64424d257e8b398'] = '¿Qué hace este módulo?';
$_MODULE['<{cronjobs}prestashop>configure_c22203a97c7dd88dd68d1e864d46ee0c'] = 'Originalmente, cron es una herramienta del sistema Unix que ofrece la planificación de tareas en el tiempo: puede crear tareas cron, que luego se ejecutan periódicamente en fechas fijas, fechas o intervalos.';
$_MODULE['<{cronjobs}prestashop>configure_d24ca73e026491b9610193f36d5edec8'] = 'Este módulo le ofrece una herramienta  adaptada a cron: puede crear tareas que exigirán un determinado conjunto de direcciones URL seguras a su tienda PrestaShop, por lo tanto desencadenar actualizaciones y otras tareas automatizadas.';
$_MODULE['<{cronjobs}prestashop>task_b43ff85c4fc17955aa3ba90827d65430'] = '¡No olvide utilizar una dirección URL absoluta en el enlace de destino para que sea válido! El enlace también tiene que estar en el mismo dominio que la tienda.';


return $_MODULE;
